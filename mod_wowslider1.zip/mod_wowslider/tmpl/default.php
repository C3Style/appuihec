<?php
/**
* @title		VisualLightBox gallery module
* @version		1.2.0
* @website		http://www.visuallightbox.com
* @copyright	Copyright (C) 2011 VisualLightBox.com. All rights reserved.
*/

defined('_JEXEC') or die('Restricted access');
?>
<div id="wowslider-container1">
<div class="ws_images"><ul>
<li><img src="modules/mod_wowslider1/data1/images/heccampus.jpg" alt="HEC-Campus" title="HEC-Campus" id="wows1_0"/></li>
</ul></div>
<div class="ws_bullets"><div>
<a href="#" title="HEC-Campus"><img src="modules/mod_wowslider1/data1/tooltips/heccampus.jpg" alt="HEC-Campus"/>1</a>
</div></div>
<a class="wsl" href="http://wowslider.com">Photo Slideshow Software Free by WOWSlider.com v3.0</a>
<a href="#" class="ws_frame"></a>
<div class="ws_shadow"></div>
</div>
<script type="text/javascript" src="modules/mod_wowslider1/engine1/wowslider.js"></script>
<script type="text/javascript" src="modules/mod_wowslider1/engine1/script.js"></script>
